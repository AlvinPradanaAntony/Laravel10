<?php

return [
    'name' => 'Comment',
];
