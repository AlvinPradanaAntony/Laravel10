<template>
    <div class="p-5 w-full h-full bg-white shadow-md rounded-sm dark:bg-gray-900 overflow-hidden">
        <slot />
    </div>
</template>

<script setup>

</script>
