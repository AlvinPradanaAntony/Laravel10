export const darkModeKey = 'darkMode'
