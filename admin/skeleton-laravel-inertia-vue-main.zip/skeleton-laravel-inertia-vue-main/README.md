# Base Laravel Inertia Vue
    This was skeleton of dashboard made with Laravel 10, Inertia, and Vue 3. this skeleton also use RBAC(Role Base Action Control) using laravel spatie.