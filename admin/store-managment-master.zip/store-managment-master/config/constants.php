<?php

return [
    'order' => [
        'not_delivered' => 'لم يتم التوصيل',
        'deliverd' => 'تم التوصيل',
        'delayed' => 'تم التأجيل',
        'returned' => 'تم الأعادة',
    ]
];







