const generalLangBg = {
    brandName: "LaraQuality",
    /* Theme */
    darkMode: "Тъмна тема",
    lightMode: "Светеща тема",
    auto: "Автоматично",
    /* Error */
    somethingWentWrong: "Опа, нещо се обърка",
    /* Simple Terms */
    save: 'Запазете',
    reset: 'Нулиране',
    cancel: 'Отмяна',
    delete: 'Изтрий',
    edit: 'редактиране',
    view: 'Преглед'
};

export default generalLangBg;
