const notification_bg = {
    pendingWorks: 'Предстоящи работи',
    unfinishedTodos: 'Текущи задачи',
    unreadMessages: 'Непрочетени съобщения'
};

export default notification_bg;
