const notification_de = {
    pendingWorks: 'Ausstehende Arbeiten',
    unfinishedTodos: 'Laufende Aufgaben',
    unreadMessages: 'ungelesene Nachrichten'
};

export default notification_de;
