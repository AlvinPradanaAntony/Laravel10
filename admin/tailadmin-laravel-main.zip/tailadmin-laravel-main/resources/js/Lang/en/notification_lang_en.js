const notification_en = {
    pendingWorks: 'Pending Works',
    unfinishedTodos: 'Unfinished Todos',
    unreadMessages: 'Unread Messages'
};

export default notification_en;
