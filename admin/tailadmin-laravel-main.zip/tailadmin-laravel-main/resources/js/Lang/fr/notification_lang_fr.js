const notification_fr = {
    pendingWorks: 'Travaux en attente',
    unfinishedTodos: 'Tâches en cours',
    unreadMessages: 'Messages non lus'
};

export default notification_fr;
