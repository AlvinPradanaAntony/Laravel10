const pagination_tr = {
    detailText: "Toplam: {totalPage} sayfa {totalRecord} kayıt",
    previous: "Önceki",
    next: "Sonraki",
}

export default pagination_tr
