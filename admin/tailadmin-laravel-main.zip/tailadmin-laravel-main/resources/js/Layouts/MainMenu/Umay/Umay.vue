<template>

</template>

<script>
export default {
    name: "ClassicMenu"
}
</script>

<style scoped>

</style>
