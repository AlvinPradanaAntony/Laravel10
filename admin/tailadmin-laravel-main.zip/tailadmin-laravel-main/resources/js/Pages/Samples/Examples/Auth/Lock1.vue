<template>
    <t-lock
        color="solid-white"
        :radius="5"
        bg-image="/img/samples/bgFakurianDesign-nY14Fs8pxT8-unsplash.jpg"
        button-color="pink"
    >
    </t-lock>
</template>

<script>
import TLock from "@/Components/Auth/TLock";

export default {
    components: {TLock}
}
</script>
