<template>
  <app-layout>
    <template #header>Email Application Page</template>
    <template #subHeader></template>
    <template #default>

    </template>
  </app-layout>
</template>

<script>
import AppLayout from "@/Layouts/AppLayout";

export default {
  name: "EmailApp",
  components: {AppLayout}
}
</script>

<style scoped>

</style>