<template>
  <app-layout>
    <template #header>Pricing Page</template>
    <template #subHeader></template>
    <template #default>

    </template>
  </app-layout>
</template>

<script>
import AppLayout from "@/Layouts/AppLayout";

export default {
  name: "Pricing",
  components: {AppLayout}
}
</script>

<style scoped>

</style>